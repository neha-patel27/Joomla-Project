<?php

namespace Joomla\Component\HelloWorld\Administrator\View\Hello;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView {
    
    function display($tpl = null) {
        parent::display($tpl);
    }

}