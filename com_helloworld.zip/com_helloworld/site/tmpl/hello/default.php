<?php

defined('_JEXEC') or die('Restricted Access');
?>
<h2>Hello world!</h2>