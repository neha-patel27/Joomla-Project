<?php
defined('_JEXEC') or die;


define('OPENWEATHER_BASE_URL', 'https://api.openweathermap.org/data/2.5/');