<?php defined('_JEXEC') or die; ?>

<div class="currency-converter border p-3 rounded">

    <input type="number" id="amount" value="<?= $defaultAmount ?>" step="0.01" class="form-control mb-2">

    <label>From</label>
    <select id="from" class="form-control mb-2">
        <?php foreach ($rates as $code => $rate) : ?>
            <option value="<?= $rate ?>" <?= $code === $defaultFrom ? 'selected' : '' ?>>
                <?= $code ?>
            </option>
        <?php endforeach; ?>
    </select>

    <label>To</label>
    <select id="to" class="form-control mb-2">
        <?php foreach ($rates as $code => $rate) : ?>
            <option value="<?= $rate ?>" <?= $code === $defaultTo ? 'selected' : '' ?>>
                <?= $code ?>
            </option>
        <?php endforeach; ?>
    </select>

    <div class="mt-2">
        Result: <strong><span id="result">0</span></strong>
    </div>
</div>

<script>
function convertCurrency() {
    let amount = parseFloat(document.getElementById('amount').value);
    let fromRate = parseFloat(document.getElementById('from').value);
    let toRate = parseFloat(document.getElementById('to').value);

    if (isNaN(amount)) amount = 0;

    let result = (amount / fromRate) * toRate;
    document.getElementById('result').innerText = result.toFixed(2);
}

document.querySelector('.currency-converter').addEventListener('input', convertCurrency);


convertCurrency();
</script>
