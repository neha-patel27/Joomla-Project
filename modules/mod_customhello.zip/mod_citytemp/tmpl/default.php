<?php defined('_JEXEC') or die; ?>


<?php if ($data) : ?>
<div class="city-temp-module">
<h4><?php echo htmlspecialchars($data['city']); ?></h4>
<p><strong><?php echo $data['temperature']; ?>°C</strong></p>
<p><?php echo htmlspecialchars($data['description']); ?></p>
</div>
<?php else : ?>
<p>Weather data not available.</p>
<?php endif; ?>