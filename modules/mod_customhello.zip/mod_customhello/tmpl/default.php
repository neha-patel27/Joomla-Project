<?php
defined('_JEXEC') or die;
?>

<div class="custom-hello-module">
    <h3><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></h3>
</div>
