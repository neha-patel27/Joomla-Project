<?php
defined('_JEXEC') or die;

class ModCustomHelloHelper
{
    public static function getMessage($params)
    {
        return $params->get('custom_message', 'Hello World!');
    }
}
