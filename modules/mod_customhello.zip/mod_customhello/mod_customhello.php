<?php
defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$message = ModCustomHelloHelper::getMessage($params);

require ModuleHelper::getLayoutPath('mod_customhello');
