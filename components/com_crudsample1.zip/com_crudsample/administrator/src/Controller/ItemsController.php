<?php
namespace Joomla\Component\Crudsample\Administrator\Controller;
defined('_JEXEC') or die;


use Joomla\CMS\MVC\Controller\AdminController;

class ItemsController extends AdminController
{
    protected $text_prefix = 'COM_CRUDSAMPLE';
}
