<?php
namespace Joomla\Component\Crudsample\Administrator\Controller;
defined('_JEXEC') or die;


use Joomla\CMS\MVC\Controller\BaseController;

class DisplayController extends BaseController
{
    protected $default_view = 'items';
}
