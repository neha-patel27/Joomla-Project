<?php
namespace Joomla\Component\Crudsample\Site\View\Import;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
    public function display($tpl = null)
    {
        parent::display($tpl);
    }
}
