<?php
namespace Joomla\Component\Crudsample\Site\Controller;

use Joomla\CMS\MVC\Controller\BaseController;

class ItemsController extends BaseController
{
    protected $default_view = 'items';
}
