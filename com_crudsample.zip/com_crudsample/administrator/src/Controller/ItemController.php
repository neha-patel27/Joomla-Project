<?php
namespace Joomla\Component\Crudsample\Administrator\Controller;

use Joomla\CMS\MVC\Controller\FormController;

class ItemController extends FormController
{
    protected $view_list = 'items';
}

